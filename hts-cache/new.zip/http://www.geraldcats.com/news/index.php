<!DOCTYPE html>
<html lang="en">
<head>
<!-- 行銷 -->
<!--[if lt IE 9]><script src="../js/html5.js"></script><![endif]-->
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta http-equiv="Content-Language" content="zh-Tw">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta http-equiv="Content-Script-Type" content="text/javascript">
	<meta http-equiv="Content-Style-Type" content="text/css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">


	<meta property="og:locale" content="zh_TW" />
	<meta property="og:type" content="website" />
	<meta property="og:site_name" content="美樂地貓坊-布偶貓買賣,布偶幼貓買賣,台中布偶幼貓買賣" />
	<meta property="og:url" content="www.geraldcats.com" />
	<meta property="og:description" content="訊息分享-美樂地專營布偶貓之培育、販售，我們擁有100%優良血統繁育符合品種標準的布偶貓，配合特寵法實施申請為特寵業繁字第s1100031號-01是台中合法登記在案的貓咪培育貓舍唷!;" />
	<meta property="og:url" content="www.geraldcats.com" />
	<meta property="og:image" content="" /> 


	<title>訊息分享-美樂地貓坊-布偶貓買賣,布偶幼貓買賣,台中布偶幼貓買賣</title>
	<meta name="keywords" content="訊息分享" />
	<meta name="description" content="美樂地專營布偶貓之培育、販售，我們擁有100%優良血統繁育符合品種標準的布偶貓，配合特寵法實施申請為特寵業繁字第s1100031號-01是台中合法登記在案的貓咪培育貓舍唷!;" />
	<link rel="shortcut icon" href="../favicon.ico">
	

<!-- -->
<script type="text/javascript" src="../js/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="../js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="../js/jquery.mmenu.all.js"></script>
<link href="https://fonts.googleapis.com/css?family=Josefin+Sans:600|Roboto" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="../css/normalize.css" />
<link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="../css/animate.min.css" />
<link rel="stylesheet" type="text/css" href="../css/jquery.mmenu.all.css" />
<link rel="stylesheet" type="text/css" href="../css/menu.css" />
<link rel="stylesheet" type="text/css" href="../css/menu_v2_2020.css" />
<link rel="stylesheet" type="text/css" href="../css/custom.css" />

	
</head>

<body class="blog_page">

<div id="page">
<style>
/*抬頭背景顏色*/
#header {
    background: ;
}

/*抬頭文字顏色*/
#menuTop li a,
.search_link a,
.topTop a i,
.search_txt + .fa {
	color: ;
}
.search_txt,
#menuTop li ul {
	border: 1px solid ;
}
.product-layer-two li a:after {
	border-color: transparent  transparent transparent;
}

/*第一層背景顏色*/
#menuTop li,
.product-layer-two li li,
.product-layer-two li li a {
	background: ;
}
/*第一層文字顏色*/
#menuTop li li a,
.product-layer-two li li a {
	color: ;
}

.product-layer-two li:hover ul {
	border:1px solid ;
	border-top: 2px solid ;	
}

/*第一層滑過背景顏色*/
#menuTop li li:hover,
.product-layer-two li li:hover a,
.product-layer-two li li:hover{
	background: ;
}
/*第一層滑過文字顏色*/
#menuTop li li:hover a,
.product-layer-two li li:hover a{
	color: ;
}


/*第二層背景顏色*/
.other_subalbum li {
	background: ;
}
/*第二層文字顏色*/
.other_subalbum li {
	border: 1px solid ;
}
.subalbum-menu h2,
.other_subalbum li a,
.product_pic #bx-pager {
	color: ;
}
/*第二層滑過背景顏色*/
.other_subalbum li:hover,
.other_subalbum li.active {
	background: ;
}
/*第二層滑過文字顏色*/
.other_subalbum li:hover,
.other_subalbum li.active {
    border: 1px solid ;
}
.other_subalbum li:hover a,
.other_subalbum li.active a {
    color: ;
}

/*第三層背景顏色*/
.products-list .more {
    color: ;
}
.products-list .price b {
	color: ;
}

/*第三層滑過背景顏色*/
.other_album_choice li,
.products-list a:hover .more {
    background: ;
}
.products-list a:hover .more {
	border-color: ;
}
/*第三層滑過文字顏色*/
.other_album_choice li a,
.products-list a:hover .more {
    color: ;
}
</style>  




<header class="header_area">
  <div class="main_header_area animated">
    <div class="container">
      <nav id="navigation1" class="navigation">
        
        <div class="nav-header">
          <a class="nav-brand" href="http://www.geraldcats.com"><img src="https://www.doing-housework.com/store_image/gerald/L166001114397.png" alt="美樂地貓坊-布偶貓買賣,布偶幼貓買賣,台中布偶幼貓買賣"/><h1>美樂地貓坊-布偶貓買賣,布偶幼貓買賣,台中布偶幼貓買賣</h1></a>
          <div class="nav-toggle"></div>
        </div>
        
       
        
        <div class="nav-menus-wrapper">
          
          <a class="nav-brand-m" href="http://www.geraldcats.com"><img src="https://www.doing-housework.com/store_image/gerald/L166001114397.png" alt="美樂地貓坊-布偶貓買賣,布偶幼貓買賣,台中布偶幼貓買賣"/></a>
          
          <ul class="nav-menu align-to-right">
                    		<li><a href="http://www.geraldcats.com" target="_self">關於我們</a>
                	                </li>
                    		<li><a href="http://www.geraldcats.com/products/index.php?title_id=5370" target="_self">布偶小貓</a>
                	                    <ul class="nav-dropdown">
                    	                            <li><a href="http://www.geraldcats.com/products/index.php?group_id=2555&title_id=5370#prod_cbox">貓咪品種</a>
                                                          </li>
                                                     <li><a href="http://www.geraldcats.com/products/index.php?group_id=2556&title_id=5370#prod_cbox">貓咪品種</a>
                                                          </li>
                                                                      	 </ul>
                        
                                    </li>
                    		<li><a href="http://www.geraldcats.com/album/index.php?title_id=5371" target="_self">國王與皇后</a>
                	 
                    	
							                            <ul class="nav-dropdown">
								                                <li><a href="http://www.geraldcats.com/album/info.php?id=2021&title_id=5371#prod_cbox">貓咪品種</a></li>
                                                                <li><a href="http://www.geraldcats.com/album/info.php?id=2022&title_id=5371#prod_cbox">貓咪品種</a></li>
                                                                <li><a href="http://www.geraldcats.com/album/info.php?id=2023&title_id=5371#prod_cbox">貓咪品種</a></li>
                                                            </ul>
                                              
                                    </li>
                    		<li><a href="http://www.facebook.com/111107804739820/videos" target="_self">影片直擊</a>
                	                </li>
                    		<li><a href="http://www.geraldcats.com/news/index.php?title_id=5373" target="_self">訊息分享</a>
                	                    	<ul class="nav-dropdown">
                    	                            <li><a href="http://www.geraldcats.com/news/index.php?group_id=1524&title_id=5373#prod_cbox">最新消息</a>
                                                          </li>
                                                     <li><a href="http://www.geraldcats.com/news/index.php?group_id=1525&title_id=5373#prod_cbox">好評分享</a>
                                                          </li>
                                             	</ul>
                                    </li>
                    		<li><a href="http://www.geraldcats.com/paper/contact_index.php?title_id=5709" target="_self">聯絡貓坊</a>
                	                </li>
                    
            <li class="tp_links">
                                           <a class="me_tp_call" href="tel: "></a>              <a class="me_tp_mail" href="mailto:gerald6226@gmail.com"></a>			</li>
          </ul>
        </div>
           
      </nav><!--navigation-->
    </div>
  </div>
</header>


<div id="content">
	
    <div class="banner banblog"><h5>訊息分享</h5></div><!-- banner -->
	
    <div class="main_part">
	
    	<div class="path">
			<p><a href="../index.php">首頁</a> > 訊息分享</p>
		</div><!-- path -->
        
		<div class="show_content blog_box clearfix">
          
          <div class="blog_le fadeInLeft animated15 clearfix">
            <h5 class="blog_le_t"><em>文章分類</em><span>Article</span></h5>
            
<div class="blog_search"><form action="http://www.geraldcats.com/news/index.php" method="get"><input type="search" name="keyword_a" value="" placeholder="文章搜尋"><input type="submit" name="" id="" value=""></form></div>
            
<ul id="accordion" class="accordion">
        <li ><!--預設打開 也可不開-->
        <div class="link"><a href="http://www.geraldcats.com/news/index.php?group_id=1524&title_id=5709#prod_cbox">最新消息</a> </div>
              </li>
        <li ><!--預設打開 也可不開-->
        <div class="link"><a href="http://www.geraldcats.com/news/index.php?group_id=1525&title_id=5709#prod_cbox">好評分享</a> </div>
              </li>
  </ul>          </div>
          
          <div class="blog_ri fadeInRight animated15 clearfix">
            
            <h4 class="blog_category_title"></h4>
            
            <div class="blog_subbox clearfix">
              
                           <div class="subbox_item">
              <a href="details.php?id=6279">
                <div class="blog_list_le"><img src="https://www.doing-housework.com/store_image/gerald/H166011634983.jpg"></div>
                <div class="blog_list_ri">
                  <h5>網站架設中，敬請期待~~</h5>
                  <em>發佈：2022/08/10</em>
                  <p>美樂地是私人住家同時也是小型的家庭式貓舍 (並非寵物店)，因此平時未經預約不對外開放，亦沒有所謂的營業時間。<br />
秉持著對每一隻布偶貓咪的熱愛，以最嚴謹的態度關注小可愛的身心健康(貓咪均有定</p>
                </div>
              </a>
              </div><!--subbox_item-->
              
              
            </div><!--blog_subbox-->
            
            <ul class="page">
			              </ul>
            
          </div>
          
		</div><!-- show_content blog_box -->
        
	</div><!-- main_part -->
</div><!-- #content -->


<a id="to_top" class="to_top" href=""><i class='top'></i>TOP</a>


<!-- ******************************** -->
<!-- 有購物車 加上下方 id#bottom_menu -->
<ul id="bottom_menu" class="clearfix with_shopping_mode">
	<li><a href="http://www.geraldcats.com"><i class="fa fa-home fa-2x" aria-hidden="true"></i>回首頁</a></li>
	    				<li><a href="tel: "><i class="fa fa-phone fa-2x" aria-hidden="true"></i>電話</a></li>
		            </ul>



<!-- ******************************** -->
<!-- 有購物車 額外加上with_shopping_mode -->
<footer class="footer with_shopping_mode"><!-- 有購物車 加上with_shopping_mode -->
	<div class="center">
		<ul class="box_link">
								</ul>
		<div class="footer_info">	
						
			<div class="footer_logo">
				<a href="http://www.geraldcats.com"><img src="https://www.doing-housework.com/store_image/gerald/L166001114397.png" alt="美樂地貓坊-布偶貓買賣,布偶幼貓買賣,台中布偶幼貓買賣" /></a>
			</div><!-- footer_logo -->
						<ul>
            <li>
				<p class="tel"> </p>                                <p class="phone">0931233131</p>                <p class="fax">gerald6226</p>								<p class="mail">gerald6226@gmail.com</p>				<p class="add">台中市梧棲區文華街54號</p>							</li>
            <li>
            	<div class="footer_menu">
                <a href="http://www.geraldcats.com/index.php">回首頁</a>
				                <a href="http://www.geraldcats.com">關於我們</a>
				                <a href="http://www.geraldcats.com/products/index.php?title_id=5370">布偶小貓</a>
				                <a href="http://www.geraldcats.com/album/index.php?title_id=5371">國王與皇后</a>
				                <a href="http://www.facebook.com/111107804739820/videos">影片直擊</a>
				                <a href="http://www.geraldcats.com/news/index.php?title_id=5373">訊息分享</a>
				                <a href="http://www.geraldcats.com/paper/contact_index.php?title_id=5709">聯絡貓坊</a>
				                </div>
            </li>
            </ul>
            	<style>
    .double_key { text-align: center;}
    .double_key a { font-size: 12px; color: #888888; display: inline-block;}
    .double_key a:after { content: ' , '; font-size: 14px; color: #698786;}
    .double_key a:last-child:after {display:none;}
    
    </style>
    <div class="double_key">
    <a href="http://www.geraldcats.com/">布偶貓買賣</a>
    <a href="http://www.geraldcats.com/">布偶幼貓買賣</a>
    <a href="http://www.geraldcats.com/">台中布偶貓買賣</a>
    <a href="http://www.geraldcats.com/">梧棲布偶貓買賣</a>
    </div><!--double_key-->


<style type="text/css">
.fix_ri { width:100px; box-sizing: border-box; position: fixed; bottom:80px; right:20px; z-index: 999; text-align:center; }
.fix_ri a { display:inline-block;margin-bottom:18px;}
.fix_ri a:hover{
    transition: all 0.3s;
    transform: rotate(-11deg);
}
.fix_ri img { opacity:1; width:100%;}
.fix_ri img:hover { opacity:1;}
.fix_ri p { text-align:center; font-weight: 900;font-size: 8px;}
@media screen and (max-width: 768px) {

.fix_ri { right: 3px;}
.fix_ri img {width: 75%;}




}
</style>

<div class="fix_ri">
    <a href="https://line.me/R/ti/p/~gerald6226" target="_blank"><img src="https://pic03.eapple.com.tw/gerald/line.png" /></a><!--line-->
    <a href="tel:0931233131"><img src="https://pic03.eapple.com.tw/gerald/phone.png" /></a><!--call-->
    <a href="https://www.facebook.com/%E7%BE%8E%E6%A8%82%E5%9C%B0%E8%B2%93%E5%9D%8A%E7%89%B9%E5%AF%B5%E6%A5%AD%E7%B9%81%E5%AD%97%E7%AC%ACs1100031%E8%99%9F-01-111107804739820" target="_blank"><img src="https://pic03.eapple.com.tw/gerald/fb.png"></a><!--fb-->
</div>
		</div><!-- footer_info -->
        
		        
	</div><!-- center -->
	<p class="copy">Designed by <a href="http://www.ykqk.com.tw" target="_blank">揚京快客</a> Copyright © 2022 <a href="https://www.doing-housework.com/web_login/login.php" target="_blank">..</a> <span class="total_view">累積人氣: 18801</span></p>
	<p class="keywords">	
	布偶貓買賣,布偶幼貓買賣,台中布偶貓買賣,梧棲布偶貓買賣,北屯布偶貓買賣,台中布偶幼貓買賣<span id="show_itemb1" style="display:none">,梧棲布偶幼貓買賣,北屯布偶幼貓買賣,布偶貓舍,台中布偶貓舍,梧棲布偶貓舍,北屯布偶貓舍,布偶貓專賣店,台中布偶貓專賣店,梧棲布偶貓專賣店,北屯布偶貓專賣店,布偶貓繁殖場,台中布偶貓繁殖場,梧棲布偶貓繁殖場,北屯布偶貓繁殖場,飼養布偶貓,台中飼養布偶貓,梧棲飼養布偶貓,北屯飼養布偶貓,布偶貓領養,台中布偶貓領養,梧棲布偶貓領養,北屯布偶貓領養,純種長毛貓,台中純種長毛貓,梧棲純種長毛貓,北屯純種長毛貓,布偶幼貓,台中布偶幼貓,梧棲布偶幼貓,北屯布偶幼貓,買布偶幼貓,台中買布偶幼貓,梧棲買布偶幼貓,北屯買布偶幼貓,貓舍,台中貓舍,梧棲貓舍,北屯貓舍,貓咪買賣,台中貓咪買賣,梧棲貓咪買賣,北屯貓咪買賣,貓咪專賣店,台中貓咪專賣店,梧棲貓咪專賣店,北屯貓咪專賣店,合法貓舍,台中合法貓舍,梧棲合法貓舍,北屯合法貓舍,合法買貓,台中合法買貓,梧棲合法買貓,北屯合法買貓,幼貓買賣,台中幼貓買賣,梧棲幼貓買賣,北屯幼貓買賣,幼貓買賣推薦,台中幼貓買賣推薦,幼貓出售,台中幼貓出售,梧棲幼貓出售,北屯幼貓出售</span>&nbsp;&nbsp;<span id="NoButtonb1"><input type="button" value="更多" style="width:50px;height:20px;" onclick="MoreItem('yes','b1')"/></span><span id="YesButtonb1" style="display:none"><input type="button" value="隱藏" style="width:50px;height:20px;" onclick="MoreItem('no','b1')"/></span></p>
</footer>
			
</div><!-- #page -->
<script src='../js/main.js'></script>
<script src='../js/menu_v2_2020.js'></script>
<script>
//左邊分類下拉語法
$(function() {
	var Accordion = function(el, multiple) {
		this.el = el || {};
		this.multiple = multiple || false;

		// Variables privadas
		var links = this.el.find('.link');
		// Evento
		links.on('click', {el: this.el, multiple: this.multiple}, this.dropdown)
	}

	Accordion.prototype.dropdown = function(e) {
		var $el = e.data.el;
			$this = $(this),
			$next = $this.next();

		$next.slideToggle();
		$this.parent().toggleClass('open');

		if (!e.data.multiple) {
			$el.find('.submenu').not($next).slideUp().parent().removeClass('open');
		};
	}	

	var accordion = new Accordion($('#accordion'), false);
});
</script>

	</body>
</html>