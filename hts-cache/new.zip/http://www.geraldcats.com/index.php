<!DOCTYPE html>
<html lang="en">
<head>
<!-- 行銷 -->


<!--[if lt IE 9]><script src="js/html5.js"></script><![endif]-->
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta http-equiv="Content-Language" content="zh-Tw">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta http-equiv="Content-Script-Type" content="text/javascript">
	<meta http-equiv="Content-Style-Type" content="text/css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<meta property="og:locale" content="zh_TW" />
	<meta property="og:type" content="website" />
	<meta property="og:site_name" content="美樂地貓坊-布偶貓買賣,布偶幼貓買賣,台中布偶幼貓買賣" />
	<meta property="og:title" content="美樂地貓坊-布偶貓買賣,布偶幼貓買賣,台中布偶幼貓買賣" />
	<meta property="og:description" content="美樂地專營布偶貓之培育、販售，我們擁有100%優良血統繁育符合品種標準的布偶貓，配合特寵法實施申請為特寵業繁字第s1100031號-01是台中合法登記在案的貓咪培育貓舍唷!," />
	<meta property="og:url" content="www.geraldcats.com" />
	<meta property="og:image" content="" /> 


	<title>美樂地貓坊-布偶貓買賣,布偶幼貓買賣,台中布偶幼貓買賣</title>
	<meta name="keywords" content="美樂地貓坊-布偶貓買賣,布偶幼貓買賣,台中布偶幼貓買賣-布偶貓買賣,布偶幼貓買賣,台中布偶貓買賣,梧棲布偶貓買賣,北屯布偶貓買賣,台中布偶幼貓買賣,梧棲布偶幼貓買賣,北屯布偶幼貓買賣,布偶貓舍,台中布偶貓舍,梧棲布偶貓舍,北屯布偶貓舍,布偶貓專賣店,台中布偶貓專賣店,梧棲布偶貓專賣店,北屯布偶貓專賣店,布偶貓繁殖場,台中布偶貓繁殖場,梧棲布偶貓繁殖場,北屯布偶貓繁殖場,飼養布偶貓,台中飼養布偶貓,梧棲飼養布偶貓,北屯飼養布偶貓,布偶貓領養,台中布偶貓領養,梧棲布偶貓領養,北屯布偶貓領養,純種長毛貓,台中純種長毛貓,梧棲純種長毛貓,北屯純種長毛貓,布偶幼貓,台中布偶幼貓,梧棲布偶幼貓,北屯布偶幼貓,買布偶幼貓,台中買布偶幼貓,梧棲買布偶幼貓,北屯買布偶幼貓,貓舍,台中貓舍,梧棲貓舍,北屯貓舍,貓咪買賣,台中貓咪買賣,梧棲貓咪買賣,北屯貓咪買賣,貓咪專賣店,台中貓咪專賣店,梧棲貓咪專賣店,北屯貓咪專賣店,合法貓舍,台中合法貓舍,梧棲合法貓舍,北屯合法貓舍,合法買貓,台中合法買貓,梧棲合法買貓,北屯合法買貓,幼貓買賣,台中幼貓買賣,梧棲幼貓買賣,北屯幼貓買賣,幼貓買賣推薦,台中幼貓買賣推薦,幼貓出售,台中幼貓出售,梧棲幼貓出售,北屯幼貓出售" />
	<meta name="description" content="美樂地專營布偶貓之培育、販售，我們擁有100%優良血統繁育符合品種標準的布偶貓，配合特寵法實施申請為特寵業繁字第s1100031號-01是台中合法登記在案的貓咪培育貓舍唷!," />
	<link rel="shortcut icon" href="favicon.ico">

<!-- -->
<script type="text/javascript" src="js/jquery-1.11.3.min.js"></script>
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="js/jquery.mmenu.all.js"></script>
<link href="https://fonts.googleapis.com/css?family=Josefin+Sans:600|Roboto" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/normalize.css" />
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/animate.min.css" />
<link rel="stylesheet" type="text/css" href="css/jquery.mmenu.all.css" />
<link rel="stylesheet" type="text/css" href="css/jquery.bxslider.css">
<link rel="stylesheet" type="text/css" href="css/menu.css" />
<link rel="stylesheet" type="text/css" href="css/menu_v2_2020.css" />
<link rel="stylesheet" type="text/css" href="css/swiper.min.css" /><!-- update by shiny at 1080710 -->
<link rel="stylesheet" type="text/css" href="css/main.css"><!-- update by shiny at 1080710 -->
<link rel="stylesheet" type="text/css" href="css/custom.css" />


							

</head>

<body class="pageIndex">

<div id="page">
<style>
/*抬頭背景顏色*/
#header {
    background: ;
}

/*抬頭文字顏色*/
#menuTop li a,
.search_link a,
.topTop a i,
.search_txt + .fa {
	color: ;
}
.search_txt,
#menuTop li ul {
	border: 1px solid ;
}
.product-layer-two li a:after {
	border-color: transparent  transparent transparent;
}

/*第一層背景顏色*/
#menuTop li,
.product-layer-two li li,
.product-layer-two li li a {
	background: ;
}
/*第一層文字顏色*/
#menuTop li li a,
.product-layer-two li li a {
	color: ;
}

.product-layer-two li:hover ul {
	border:1px solid ;
	border-top: 2px solid ;	
}

/*第一層滑過背景顏色*/
#menuTop li li:hover,
.product-layer-two li li:hover a,
.product-layer-two li li:hover{
	background: ;
}
/*第一層滑過文字顏色*/
#menuTop li li:hover a,
.product-layer-two li li:hover a{
	color: ;
}


/*第二層背景顏色*/
.other_subalbum li {
	background: ;
}
/*第二層文字顏色*/
.other_subalbum li {
	border: 1px solid ;
}
.subalbum-menu h2,
.other_subalbum li a,
.product_pic #bx-pager {
	color: ;
}
/*第二層滑過背景顏色*/
.other_subalbum li:hover,
.other_subalbum li.active {
	background: ;
}
/*第二層滑過文字顏色*/
.other_subalbum li:hover,
.other_subalbum li.active {
    border: 1px solid ;
}
.other_subalbum li:hover a,
.other_subalbum li.active a {
    color: ;
}

/*第三層背景顏色*/
.products-list .more {
    color: ;
}
.products-list .price b {
	color: ;
}

/*第三層滑過背景顏色*/
.other_album_choice li,
.products-list a:hover .more {
    background: ;
}
.products-list a:hover .more {
	border-color: ;
}
/*第三層滑過文字顏色*/
.other_album_choice li a,
.products-list a:hover .more {
    color: ;
}
</style>  




<header class="header_area">
  <div class="main_header_area animated">
    <div class="container">
      <nav id="navigation1" class="navigation">
        
        <div class="nav-header">
          <a class="nav-brand" href="http://www.geraldcats.com"><img src="https://www.doing-housework.com/store_image/gerald/L166001114397.png" alt="美樂地貓坊-布偶貓買賣,布偶幼貓買賣,台中布偶幼貓買賣"/><h1>美樂地貓坊-布偶貓買賣,布偶幼貓買賣,台中布偶幼貓買賣</h1></a>
          <div class="nav-toggle"></div>
        </div>
        
       
        
        <div class="nav-menus-wrapper">
          
          <a class="nav-brand-m" href="http://www.geraldcats.com"><img src="https://www.doing-housework.com/store_image/gerald/L166001114397.png" alt="美樂地貓坊-布偶貓買賣,布偶幼貓買賣,台中布偶幼貓買賣"/></a>
          
          <ul class="nav-menu align-to-right">
                    		<li><a href="http://www.geraldcats.com" target="_self">關於我們</a>
                	                </li>
                    		<li><a href="http://www.geraldcats.com/products/index.php?title_id=5370" target="_self">布偶小貓</a>
                	                    <ul class="nav-dropdown">
                    	                            <li><a href="http://www.geraldcats.com/products/index.php?group_id=2555&title_id=5370#prod_cbox">貓咪品種</a>
                                                          </li>
                                                     <li><a href="http://www.geraldcats.com/products/index.php?group_id=2556&title_id=5370#prod_cbox">貓咪品種</a>
                                                          </li>
                                                                      	 </ul>
                        
                                    </li>
                    		<li><a href="http://www.geraldcats.com/album/index.php?title_id=5371" target="_self">國王與皇后</a>
                	 
                    	
							                            <ul class="nav-dropdown">
								                                <li><a href="http://www.geraldcats.com/album/info.php?id=2021&title_id=5371#prod_cbox">貓咪品種</a></li>
                                                                <li><a href="http://www.geraldcats.com/album/info.php?id=2022&title_id=5371#prod_cbox">貓咪品種</a></li>
                                                                <li><a href="http://www.geraldcats.com/album/info.php?id=2023&title_id=5371#prod_cbox">貓咪品種</a></li>
                                                            </ul>
                                              
                                    </li>
                    		<li><a href="http://www.facebook.com/111107804739820/videos" target="_self">影片直擊</a>
                	                </li>
                    		<li><a href="http://www.geraldcats.com/news/index.php?title_id=5373" target="_self">訊息分享</a>
                	                    	<ul class="nav-dropdown">
                    	                            <li><a href="http://www.geraldcats.com/news/index.php?group_id=1524&title_id=5373#prod_cbox">最新消息</a>
                                                          </li>
                                                     <li><a href="http://www.geraldcats.com/news/index.php?group_id=1525&title_id=5373#prod_cbox">好評分享</a>
                                                          </li>
                                             	</ul>
                                    </li>
                    		<li><a href="http://www.geraldcats.com/paper/contact_index.php?title_id=5709" target="_self">聯絡貓坊</a>
                	                </li>
                    
            <li class="tp_links">
                                           <a class="me_tp_call" href="tel: "></a>              <a class="me_tp_mail" href="mailto:gerald6226@gmail.com"></a>			</li>
          </ul>
        </div>
           
      </nav><!--navigation-->
    </div>
  </div>
</header>
<div class="bannerindex">
	<div class="swiper-banner">
      <div class="swiper-wrapper">
        <div class="swiper-slide centerBig"><img src="https://www.doing-housework.com/store_image/gerald/A1166063237781.jpg" /></div>        <div class="swiper-slide"><img src="https://www.doing-housework.com/store_image/gerald/B2166063237826.jpg" /></div>                              </div>
    </div>
    <div class="swiper-pagination"></div>
</div>

<script type="text/javascript" src="js/swiper.min2.js"></script><!-- update by shiny at 1080710 -->
<script type="text/javascript">
// update by shiny at 1080710
trList=['leftUp','moveRight','moveDown','centerBig','rightDownBig'];
var swiper = new Swiper('.swiper-banner',{
	speed:1000,
	autoplay:4400,
	autoplayDisableOnInteraction:false,
	effect:'fade',
	pagination : '.swiper-pagination',
	paginationClickable :true,
	onSlideChangeStart: function(swiper){
		nextSlide=swiper.slides.eq(swiper.activeIndex);
		nextSlide.addClass(trList[Math.floor(Math.random()*5)]);
		},
	onSlideChangeEnd: function(swiper){
		prevSlide=swiper.slides[swiper.previousIndex];
		prevSlide.className="swiper-slide";
			       },
	});
</script>

<div class="mobile_wp">
	</div>


<div id="content_main">
		    	        			
	<div class="main_part">
		<div class="show_content fadeInUp animated15">

			<!-- 以下為編輯器(不含div) -->
			<div class="edit">
				<!DOCTYPE html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="https://pic03.eapple.com.tw/yk_js_web/jquery-1.11.3.min.js"></script>
<!--通用JS 預覽用 不用貼上去編輯器-->

<body>
    <script src="https://pic03.eapple.com.tw/yk_js_web/scrollfade.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif+TC:wght@400;500;600&display=swap" rel="stylesheet">

    <style type="text/css">
        /* -- reset module8 -- */
        .edit,
        .show_content,
        .main_part {
            width: 100%;
            max-width: 100%;
            margin: auto;
            padding: 0px 0px;
        }

        .show_content {
            width: 100%;
            margin: auto;
            padding: 0px 0px;
        }

        .center_box {
            width: 100%;
            margin: 0 auto;
        }

        .path,
        .banner {
            display: none;
        }

        .pageIndex .main_part {
            border: none !important;
        }

        /*Animations*/
        [data-animate-in] {
            opacity: 0;
            transition: transform 1.5s ease, opacity 1.5s ease;
        }

        [data-animate-in="up"] {
            transform: translate3d(0, 10%, 0);
        }

        /*由下往上*/
        [data-animate-in="left"] {
            transform: translate3d(-50%, 0, 0);
        }

        /*由左往右*/
        [data-animate-in="right"] {
            transform: translate3d(50%, 0, 0);
        }

        /*由右往左*/
        [data-animate-in="down"] {
            transform: translate3d(0, -10%, 0);
        }

        /*由上往下*/
        [data-animate-in="fadeIn"] {
            transform: translate3d(0, 0, 0);
        }

        /*淡入*/
        [data-animate-in="scaleIn"] {
            transform: scale(.3);
        }

        /*放大淡入*/
        [data-animate-in="rotateIn"] {
            transform: scale(.3) rotate(-10deg);
        }

        /*放大淡入*/
        [data-animate-in].in-view {
            opacity: 1;
            transform: translate3d(0, 0, 0) rotate(0deg);
            -webkit-transform: translate3d(0, 0, 0) rotate(0);
            transition: transform 1.5s ease, opacity 1.5s ease;
        }

        .fade-in {
            opacity: 0;
            transition: opacity 1.5s ease;
        }

        /*Animations-end*/

        .hs_box * {
            line-height: 180%;
            font-size: 16px;
            border: 0;
            outline: none;
            text-decoration: none;
            padding: 0;
            margin: 0;
            list-style: none;
            box-sizing: border-box;
            max-width: 100%;
            font-family: 'Microsoft JhengHei UI';
            color: #000;
            overflow-wrap: break-word;
            -webkit-transition: ease .3s;
            -moz-transition: ease .3s;
            -ms-transition: ease .3s;
            -o-transition: ease .3s;
            transition: ease .3s;
        }

        .hs_box img {
            max-width: 100%;
        }

        .hs_clear::before,
        .hs_clear::after {
            content: '';
            display: table;
        }

        .hs_clear::after {
            clear: both;
        }

        .hs_clear {
            zoom: 1;
        }

        .hs_box {
            overflow: hidden;
            max-width: 2000px;
            margin: auto;
        }

        /* 共用 */

        .yp_w1200 {
            max-width: 1200px;
            margin: 0 auto;
        }

        .d-flex {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            align-content: center;
        }

        .text-center {
            text-align: center;
        }

        .lg_tititit {
            margin-top: 30px;
        }

        .lg_i h6 {
            color: #444444;
            font-size: 18px;
            margin: 20px 0;
            font-weight: 500;
        }

        .lg_i a {
            color: rgb(255, 255, 255);
            font-size: 16px;
            margin: 10px 30px 0 0;
            letter-spacing: 7px;
            text-align: right;
            padding-right: 16px;
            line-height: 52px;

            width: 168px;
            height: 52px;
            background-position: center;
            background-repeat: no-repeat;
            background-size: contain;



        }

        .lg_i p {
            color: #444444;
            font-size: 16px;
            margin: 5px 0px;
        }

        .lg_i .h7 {
            color: #FF0000;
            font-size: 16px;
            font-weight: bold;
            margin-left: 8px;
        }

        /* main */
        .lg_i_01,
        .lg_i_02,
        .lg_i_03,
        .lg_i_04,
        .lg_i_05 {
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;

            padding: 120px 0;
        }

        .lg_i_01,
        .lg_i_03 {
            background-image: url(https://pic03.eapple.com.tw/gerald/lg_bg1.jpg);
        }

        .lg_i_02,
        .lg_i_04 {
            background-image: url(https://pic03.eapple.com.tw/gerald/lg_bg2.jpg);
        }

        .lg_i_05 {
            background-image: url(https://pic03.eapple.com.tw/gerald/lg_bg5.jpg);
        }

        .lg_btnb {
            background-image: url(https://pic03.eapple.com.tw/gerald/lg_btn1.png);
        }

        .lg_btng {
            background-image: url(https://pic03.eapple.com.tw/gerald/lg_btn2.png);
        }

        .lg_btno {
            background-image: url(https://pic03.eapple.com.tw/gerald/lg_btn3.png);
        }

        .lg_btnr {
            background-image: url(https://pic03.eapple.com.tw/gerald/lg_btnrrr.png);
        }

        /* 01 */
        .lg_i_01 {
            justify-content: end;
        }

        .lg_i_01l {
            max-width: 580px;
        }

        .lg_i_01r {
            margin: 0 100px 0 180px;
        }

        .lgabox {
            justify-content: space-between;

        }

        .lgabox a {
            margin: 10px 0 0;

        }


        /* 02 */
        .lg_i_02 {
            position: relative;
        }

        .lgpopo1 {
            position: absolute;
            top: 0;
            left: 0;
            transform: translate(0, -50%);
            z-index: 0;
        }

        .lg_i_02r {
            max-width: 524px;
            margin-left: 100px;
        }

        .lg_i_02r .d-flex {
            justify-content: flex-start;
        }

        .lgimgbox img {
            box-shadow: 4px 4px 8px rgba(0, 0, 0, 0.5);
            border-radius: 15px;
            position: relative;
            z-index: 5;
        }

        .lgimgbox img:first-child {
            margin: 0 30px 0 0;

        }

        .lgimgbox {
            margin-left: -100px;
        }

        /* 03 */
        .lg_i_03 {
            justify-content: end;
        }

        .lg_i_03l {
            max-width: 543px;
            margin-right: 100px;
        }

        .lg_i_03l .lgabox {
            width: 600px;
        }

        .hs_box .ggg7 {
            max-width: 940px;
        }

        /*  */
        .lg_i_04 {
            justify-content: flex-start;
            padding-left: 100px;
        }

        .lg_i_04r {
            background-color: rgba(255, 255, 255, 0.5);
            border-radius: 25px;
            position: relative;

            padding: 40px 85px 30px 180px;
            max-width: 800px;
            justify-content: end;
            margin-left: 130px;
        }

        .lgpopo2 {
            position: absolute;
            top: 50%;
            left: 0;
            transform: translate(-40%, -50%);
        }

        .i_04rww {
            max-width: 556px;
        }

        .lg_i_04 h6 {
            font-weight: 600;
            font-size: 20px;
            margin: 0;
        }

        .lg_i_04 .lg_i_04rw {
            flex-wrap: nowrap;
            justify-content: start;
        }

        .lg_i_04rw img {
            align-self: flex-start;
            margin: 5px 14px 0 0;
        }

        .lg_i_04 .lg_tititit {
            margin: 0 0 25px 0;
        }

        .lg_i_04rw {
            margin-bottom: 13px;
        }
        .lg_i_04r picture{
            margin: 0px 0 20px;
        }

        /* 05 */
        .lg_i_05 {
            padding: 150px 0 80px;
            justify-content: end;
            padding-right: 100px;
        }

        .lg_i_05l {
            flex-direction: column;
            max-width: 598px;
        }

        .lg_i_05l .d-flex {
            justify-content: flex-start;
        }

        .lg_i_05ldd {
            margin-top: 20px;
        }

        .ggg5 {
            margin-left: 50px;
        }

        /*  */
        .lg_i picture {
            margin-top: 25px;
            display: flex;
            justify-content: flex-start;

        }
        .lg_i picture source{
            height: 100%;
        }
        /*  */
        .dio a:hover{
            transform: translate(0,-10px);

        }




        /*關鍵字*/
        .key_words {
            height: 0;
            max-height: 0;
            overflow: hidden;
        }

        .key_words h2,
        .key_words h3,
        .key_words h4,
        .key_words h5,
        .key_words h6 {
            color: rgba(255, 255, 255, .0);
        }

        @media (max-width:1738px) {
            .lg_i_04 {
                padding-left: 20px;
                padding-right: 20px;
                flex-wrap: nowrap;
            }

            .lg_i_04r {
                margin-left: 80px;
                padding-right: 50px;
                padding-left: 120px;
            }

            .hs_box .ggg4 {
                max-width: 45%;
            }

            .i_04rww .d-flex:last-child {
                flex-wrap: nowrap;
            }
        }

        @media (max-width:1658px) {
            .lg_i_01 {
                padding: 120px 20px 150px;
                flex-wrap: nowrap;
            }

            .hs_box .lg_i_01r {
                margin: 0 0 0 50px;
                max-width: 50%;
            }

            /* 02 */

            .hs_box .lgimgbox {
                margin-left: 0px;
                width: 50%;
                flex-wrap: nowrap;
            }

            .hs_box .lgimgbox img {
                max-width: 280px;
            }

            .lg_i_02r {
                margin-left: 50px;
            }

            /* 03 */
            .lg_i_03 {
                padding-left: 20px;
            }

            .lg_i_03l {
                margin-right: 50px;
            }

            .hs_box .ggg7 {
                max-width: 50%;
            }

            .lgpopo2 {
                width: 200px;
            }
            /* 05 */
            .hs_box .ggg5{
                max-width: 50%;

            }
            .lg_i_05{
                padding-left: 20px;
                padding-right: 50px;
                flex-wrap: nowrap;

            }

        }

        @media (max-width:1228px) {

            .lg_i_01,
            .lg_i_02,
            .lg_i_03,
            .lg_i_04,
            .lg_i_05 {
                padding: 80px 20px;
            }

            .lg_i_01 {
                flex-direction: column;
                padding: 80px 20px 150px;
            }

            .hs_box .lg_i_01r {
                margin: 100px 0 0 0;
                max-width: 100%;
            }

            .lg_i_01l {
                display: flex;
                flex-direction: column;
                justify-items: center;

            }

            .lg_i h6 {
                text-align: center;
            }

            /* 02 */
            .lg_i_02 {
                flex-direction: column;
            }

            .lgpopo1 {
                width: 250px;
            }

            .hs_box .lgimgbox img {
                max-width: 100%;
            }

            .lg_i_02r {
                margin-left: 50px;
            }

            .hs_box .lgimgbox {
                width: 100%;
                flex-wrap: wrap;
            }

            .lgimgbox img {
                width: 40%;

            }

            .lg_i_02r {
                margin-left: 0px;
                margin-top: 50px;
            }

            .lg_i_02r .d-flex {
                justify-content: center;
            }

            /* 03 */
            .lg_i_03 {
                flex-direction: column;
                justify-content: center;
            }

            .hs_box .ggg7 {
                max-width: 100%;
                margin-top: 50px;

                margin-right: -15%;
            }

            .lg_i_03l {
                margin-right: 0px;
                max-width: 100%;
            }

            .lg_i_03l {
                display: flex;
                flex-direction: column;
                align-items: center;
            }

            /* 04 */
            .lg_i_04 {
                flex-direction: column;
            }

            .lg_i_04 picture {
                margin: 0 0 20px 0;
            }

            .lg_i_04r {
                margin: 50px 20px 0 80px;
                justify-content: center;

            }

            .i_04rwww h6 {
                text-align: start;
            }

            .hs_box .ggg4 {
                max-width: 100%;
            }
            /* 05 */
            .lg_i_05{
                flex-direction: column;

            }
            .lg_i_05l .d-flex{
                justify-content: center;
            }
            .hs_box .ggg5{
                margin: 50px 0 0 0;
                max-width: 100%;
            }

        }

        @media (max-width:1050px) {
            .hs_box .ggg7 {
                margin-right: -8%;
            }
        }

        @media (max-width:750px) {
            .lg_i_04r {
                padding-left: 80px;
                margin-left: 43px;
            }

            .lgpopo2 {
                width: 130px;
            }
        }

        @media (max-width:630px) {
            .lg_i h6 {
                margin: 5px 0;
            }

            .lgabox {
                flex-direction: column;
                justify-content: center;
            }

            .hs_box .lg_i_01r {
                margin-top: 50px;
            }

            /* 02 */
            .lgimgbox img {
                width: 80%;
            }

            .lgimgbox img:first-child {
                margin: 0 0 50px 0;
            }

            .lgimgbox {
                flex-direction: column;
            }
        }

        @media (max-width:584px) {

            .lg_i_01,
            .lg_i_02,
            .lg_i_03,
            .lg_i_04,
            .lg_i_05 {
                padding: 50px 20px;
            }

            .lg_i_01 {
                padding-bottom: 100px;
            }

            .lg_i_02 {
                padding-top: 100px;
            }

            .lg_i picture {
                margin-bottom: 10px;
                justify-content: center;

            }

            .lg_i h6 {
                font-size: 16px;
            }

            .lgpopo1 {
                width: 200px;
            }

            /* 03 */
            .hs_box .ggg7 {
                margin-right: -12%;
            }
        }

        @media (max-width:520px) {
            .lgpopo2{
                width: 100px;
                top: 0;
                transform: translate(-50%, -10%);

            }
            .lg_i_04r{
                padding: 20px;
                margin-left: 33px;

            }
            .lg_i_04rw img{
                margin-right: 8px;
                position: relative;
                z-index: 5;
            }
        }
    </style>
    <div class="key_words">
        <h2>布偶貓買賣</h2>
        <h3>布偶幼貓買賣</h3>
        <h4>台中布偶貓買賣</h4>
        <h5>梧棲布偶貓買賣</h5>
        <h6>北屯布偶貓買賣</h6>
    </div>


    <div class="hs_box lg_i">
        <section class="lg_i_01 d-flex">
            <div class="lg_i_01l">
                <img data-animate-in="left" src="https://pic03.eapple.com.tw/gerald/lg_img1.png" alt="">
<!-- 000 -->
                <picture data-animate-in="left">
                    <source srcset="https://pic03.eapple.com.tw/gerald/lg_titi1-3.png" media="(max-width: 584px)" width:344px height:100px />
                    <source srcset="https://pic03.eapple.com.tw/gerald/lg_titi1-2.png" media="(max-width: 1228px)" width:559px height:73px />
                    <img src="https://pic03.eapple.com.tw/gerald/lg_titi1.png" alt="">
                </picture>

                <h6 data-animate-in="left">美樂地專營布偶貓之培育、販售，布偶貓非常溫馴、友善、黏人、愛塞乃(撒嬌)，是會讓人想不停收集的貓種。</h6>
                <h6 data-animate-in="left">我們擁有100%優良血統繁育符合品種標準的布偶貓，配合特寵法實施，申請為特寵業繁字第s1100031號-01是台中合法登記在案的貓咪培育貓舍唷！</h6>
                <div data-animate-in="left" class="lgabox d-flex dio">
                    <a class="lg_btnb" href="http://www.geraldcats.com/products/index.php?title_id=5370">更多貓種</a>
                    <a class="lg_btng" href="https://www.facebook.com/%E7%BE%8E%E6%A8%82%E5%9C%B0%E8%B2%93%E5%9D%8A%E7%89%B9%E5%AF%B5%E6%A5%AD%E7%B9%81%E5%AD%97%E7%AC%ACs1100031%E8%99%9F-01-111107804739820/videos/">影片直擊</a>
                    <a class="lg_btno" href="http://www.geraldcats.com/paper/contact_index.php?title_id=5709">聯絡貓坊</a>
                </div>
            </div>
            <!--  -->
            <img data-animate-in="right" class="lg_i_01r" src="https://pic03.eapple.com.tw/gerald/lg_img2.png" alt="">

        </section>

        <section class="lg_i_02 d-flex">
            <img  class="lgpopo1" src="https://pic03.eapple.com.tw/gerald/lg_popo.png" alt="">
            <!--  -->
            <div data-animate-in="left" class="lgimgbox d-flex">
                <img src="https://pic03.eapple.com.tw/gerald/lg_img3.png" alt="">
                <img src="https://pic03.eapple.com.tw/gerald/lg_img4.png" alt="">
            </div>
            <!--  -->
            <div class="lg_i_02r">
                <img data-animate-in="right" src="https://pic03.eapple.com.tw/gerald/lg_img5.png" alt="">
                <picture data-animate-in="right">
                    <source srcset="https://pic03.eapple.com.tw/gerald/lg_titi2-3.png" media="(max-width: 584px)" />
                    <source srcset="https://pic03.eapple.com.tw/gerald/lg_titi2-2.png" media="(max-width: 1228px)" />
                    <img src="https://pic03.eapple.com.tw/gerald/lg_titi2.png" alt="">
                </picture>
                <h6 data-animate-in="right">我們堅持提供貓最好的生活環境、飲食、健康照護等，
                    也提供給您最好的售前售後飼養諮詢服務。</h6>
                <div data-animate-in="right" class="d-flex dio">
                    <a class="lg_btnr" href="http://www.geraldcats.com/news/index.php?title_id=5373">訊息分享</a>
                    <a class="lg_btno" href="http://www.geraldcats.com/paper/contact_index.php?title_id=5709">聯絡貓坊</a>
                </div>
            </div>


        </section>

        <section class="lg_i_03 d-flex">
            <div class="lg_i_03l">
                <img data-animate-in="left" src="https://pic03.eapple.com.tw/gerald/lg_img6.png" alt="">
                <picture data-animate-in="left">
                    <source srcset="https://pic03.eapple.com.tw/gerald/lg_titi3-3.png" media="(max-width: 584px)" />
                    <source srcset="https://pic03.eapple.com.tw/gerald/lg_titi3-2.png" media="(max-width: 1228px)" />
                    <img src="https://pic03.eapple.com.tw/gerald/lg_titi3.png" alt="">
                </picture>
                <h6 data-animate-in="left">美樂地是私人住家同時也是小型的家庭式貓舍 (並非寵物店)，
                    因此平時未經預約不對外開放，亦沒有所謂的營業時間。
                </h6>
                <h6 data-animate-in="left">秉持著對每一隻布偶貓咪的熱愛，以最嚴謹的態度關注小可愛
                    的身心健康(貓咪均有定期驅蟲)當成自己的孩子在照顧，提倡
                    多元化飲食採優質食譜餵養營養均衡並完善做好環境定期消毒
                    清潔、24小時冷暖空調，讓貓咪生活於舒適的環境空間感到快
                    樂自在，才能培育出絲綢般優良貓毛的毛小孩們喲。</h6>
                <div data-animate-in="left" class="lgabox d-flex dio">
                    <a class="lg_btnb" href="http://www.geraldcats.com/products/index.php?title_id=5370">更多貓種</a>
                    <a class="lg_btng" href="https://www.facebook.com/%E7%BE%8E%E6%A8%82%E5%9C%B0%E8%B2%93%E5%9D%8A%E7%89%B9%E5%AF%B5%E6%A5%AD%E7%B9%81%E5%AD%97%E7%AC%ACs1100031%E8%99%9F-01-111107804739820/videos/">影片直擊</a>
                    <a class="lg_btno" href="http://www.geraldcats.com/paper/contact_index.php?title_id=5709">聯絡貓坊</a>
                </div>
            </div>
            <!--  -->
            <img data-animate-in="right" class="ggg7" src="https://pic03.eapple.com.tw/gerald/lg_img7.png" alt="">

        </section>

        <section class="lg_i_04 d-flex">
            <img data-animate-in="left" class="ggg4" src="https://pic03.eapple.com.tw/gerald/lg_img8.png" alt="">
            <!--  -->
            <div class="lg_i_04r d-flex">
                <img class="lgpopo2" src="https://pic03.eapple.com.tw/gerald/lg_img9.png" alt="">
                <div class="i_04rww">
                    <picture data-animate-in="right">
                        <source srcset="https://pic03.eapple.com.tw/gerald/lg_titi4-2.png" media="(max-width: 584px)" />
                        <img src="https://pic03.eapple.com.tw/gerald/lg_titi4.png" alt="">
                    </picture>
                    <div  data-animate-in="right" class="lg_i_04rw d-flex">
                        <img src="https://pic03.eapple.com.tw/gerald/lg_4-1.png" alt="">
                        <div class="i_04rwww">
                            <h6>基礎健檢、驅蟲</h6>
                            <p>我們的貓貓出售都會做基本的健康檢查、預防接種、體內外驅蟲，如有其他疑問都歡迎您私訊。</p>
                        </div>
                    </div>
                    <!--  -->
                    <div data-animate-in="right" class="lg_i_04rw d-flex">
                        <img src="https://pic03.eapple.com.tw/gerald/lg_4-2.png" alt="">
                        <div class="i_04rwww">
                            <h6>四合一疫苗健康手冊</h6>
                            <p>貓貓們出售前會打第一劑、有任何疑問歡迎私訊。</p>
                        </div>
                    </div>
                    <!--  -->
                    <div data-animate-in="right" class="lg_i_04rw d-flex">
                        <img src="https://pic03.eapple.com.tw/gerald/lg_4-3.png" alt="">
                        <div class="i_04rwww">
                            <h6>晶片登入</h6>
                            <p>貓售出後我們會幫貴客做晶片登入，以及轉讓相關延伸費用，
                                登入完成會傳送登入完成資料給您。</p>
                        </div>
                    </div>
                    <!--  -->
                    <div data-animate-in="right" class="lg_i_04rw d-flex">
                        <img src="https://pic03.eapple.com.tw/gerald/lg_4-4.png" alt="">
                        <div class="i_04rwww">
                            <h6>購買須知</h6>
                            <p>簽訂買賣契約/付款方式/付現，貓咪晶片登入，
                                隨附：貓飼料一包、預防針手冊一本、新手教程一張。</p>
                        </div>
                    </div>
                    <!--  -->
                    <div data-animate-in="right" class="d-flex">
                        <img src="https://pic03.eapple.com.tw/gerald/lg_st.png" alt="">
                        <div class="h7">我們僅提供品質優良且健康的布偶貓，價錢都是合理的，恕不接受議價！</div>
                    </div>
                </div>


            </div>

        </section>

        <section class="lg_i_05 d-flex">
            <div class="lg_i_05l">
                <div class="lg_i_05lup">
                    <picture data-animate-in="left">
                        <source srcset="https://pic03.eapple.com.tw/gerald/lg_titi5-3.png" media="(max-width: 584px)" />
                        <source srcset="https://pic03.eapple.com.tw/gerald/lg_titi5-2.png" media="(max-width: 1228px)" />
                        <img src="https://pic03.eapple.com.tw/gerald/lg_titi5.png" alt="">
                    </picture>
                    <h6 data-animate-in="left">美樂地貓坊 不定時都會在FB粉絲專頁，此官網更新貓舍裡的生活大小事，
                        可以追蹤我們進一步了解更多！</h6>
                    <div data-animate-in="left" class="d-flex dio">
                        <a class="lg_btng" href="https://www.facebook.com/%E7%BE%8E%E6%A8%82%E5%9C%B0%E8%B2%93%E5%9D%8A%E7%89%B9%E5%AF%B5%E6%A5%AD%E7%B9%81%E5%AD%97%E7%AC%ACs1100031%E8%99%9F-01-111107804739820/videos/">影片直擊</a>
                        <a class="lg_btnb" href="http://www.geraldcats.com/products/index.php?title_id=5370">更多貓種</a>
                    </div>
                </div>
                <div class="lg_i_05ldd">
                    <picture data-animate-in="right">
                        <source srcset="https://pic03.eapple.com.tw/gerald/lg_titi6-3.png" media="(max-width: 584px)" />
                        <source srcset="https://pic03.eapple.com.tw/gerald/lg_titi6-2.png" media="(max-width: 1228px)" />
                        <img src="https://pic03.eapple.com.tw/gerald/lg_titi6.png" alt="">
                    </picture>
                    <h6 data-animate-in="right">已選定小貓的家長，我們會定時提供照片影片，<br>
                        也可在小貓打完第一劑預防針後來訪，<br>
                        或線上視訊讓貴客能在螢幕裡看貓貓的活潑健康~</h6>
                    <div data-animate-in="right" class="d-flex dio">
                        <a class="lg_btng" href="https://line.me/R/ti/p/~gerald6226">加入好友</a>
                        <a class="lg_btno" href="http://www.geraldcats.com/paper/contact_index.php?title_id=5709">聯絡貓坊</a>
                    </div>
                </div>
            </div>

            <!--  -->
            <img data-animate-in="up" class="ggg5" src="https://pic03.eapple.com.tw/gerald/lg_img10.png" alt="">

        </section>



    </div>
</body>			</div><!-- edit -->	
			<!-- 編輯器結束 -->
			
		</div><!-- show_content -->
	</div><!-- main_part -->
	    	        		    	        		    	        		    	        		    	        </div><!-- #content_main -->


<a id="to_top" class="to_top" href=""><i class='top'></i>TOP</a>


<!-- ******************************** -->
<!-- 有購物車 加上下方 id#bottom_menu -->
<ul id="bottom_menu" class="clearfix with_shopping_mode">
	<li><a href="http://www.geraldcats.com"><i class="fa fa-home fa-2x" aria-hidden="true"></i>回首頁</a></li>
	    				<li><a href="tel: "><i class="fa fa-phone fa-2x" aria-hidden="true"></i>電話</a></li>
		            </ul>



<!-- ******************************** -->
<!-- 有購物車 額外加上with_shopping_mode -->
<footer class="footer with_shopping_mode"><!-- 有購物車 加上with_shopping_mode -->
	<div class="center">
		<ul class="box_link">
								</ul>
		<div class="footer_info">	
						
			<div class="footer_logo">
				<a href="http://www.geraldcats.com"><img src="https://www.doing-housework.com/store_image/gerald/L166001114397.png" alt="美樂地貓坊-布偶貓買賣,布偶幼貓買賣,台中布偶幼貓買賣" /></a>
			</div><!-- footer_logo -->
						<ul>
            <li>
				<p class="tel"> </p>                                <p class="phone">0931233131</p>                <p class="fax">gerald6226</p>								<p class="mail">gerald6226@gmail.com</p>				<p class="add">台中市梧棲區文華街54號</p>							</li>
            <li>
            	<div class="footer_menu">
                <a href="http://www.geraldcats.com/index.php">回首頁</a>
				                <a href="http://www.geraldcats.com">關於我們</a>
				                <a href="http://www.geraldcats.com/products/index.php?title_id=5370">布偶小貓</a>
				                <a href="http://www.geraldcats.com/album/index.php?title_id=5371">國王與皇后</a>
				                <a href="http://www.facebook.com/111107804739820/videos">影片直擊</a>
				                <a href="http://www.geraldcats.com/news/index.php?title_id=5373">訊息分享</a>
				                <a href="http://www.geraldcats.com/paper/contact_index.php?title_id=5709">聯絡貓坊</a>
				                </div>
            </li>
            </ul>
            	<style>
    .double_key { text-align: center;}
    .double_key a { font-size: 12px; color: #888888; display: inline-block;}
    .double_key a:after { content: ' , '; font-size: 14px; color: #698786;}
    .double_key a:last-child:after {display:none;}
    
    </style>
    <div class="double_key">
    <a href="http://www.geraldcats.com/">布偶貓買賣</a>
    <a href="http://www.geraldcats.com/">布偶幼貓買賣</a>
    <a href="http://www.geraldcats.com/">台中布偶貓買賣</a>
    <a href="http://www.geraldcats.com/">梧棲布偶貓買賣</a>
    </div><!--double_key-->


<style type="text/css">
.fix_ri { width:100px; box-sizing: border-box; position: fixed; bottom:80px; right:20px; z-index: 999; text-align:center; }
.fix_ri a { display:inline-block;margin-bottom:18px;}
.fix_ri a:hover{
    transition: all 0.3s;
    transform: rotate(-11deg);
}
.fix_ri img { opacity:1; width:100%;}
.fix_ri img:hover { opacity:1;}
.fix_ri p { text-align:center; font-weight: 900;font-size: 8px;}
@media screen and (max-width: 768px) {

.fix_ri { right: 3px;}
.fix_ri img {width: 75%;}




}
</style>

<div class="fix_ri">
    <a href="https://line.me/R/ti/p/~gerald6226" target="_blank"><img src="https://pic03.eapple.com.tw/gerald/line.png" /></a><!--line-->
    <a href="tel:0931233131"><img src="https://pic03.eapple.com.tw/gerald/phone.png" /></a><!--call-->
    <a href="https://www.facebook.com/%E7%BE%8E%E6%A8%82%E5%9C%B0%E8%B2%93%E5%9D%8A%E7%89%B9%E5%AF%B5%E6%A5%AD%E7%B9%81%E5%AD%97%E7%AC%ACs1100031%E8%99%9F-01-111107804739820" target="_blank"><img src="https://pic03.eapple.com.tw/gerald/fb.png"></a><!--fb-->
</div>
		</div><!-- footer_info -->
        
		        
	</div><!-- center -->
	<p class="copy">Designed by <a href="http://www.ykqk.com.tw" target="_blank">揚京快客</a> Copyright © 2022 <a href="https://www.doing-housework.com/web_login/login.php" target="_blank">..</a> <span class="total_view">累積人氣: 18795</span></p>
	<p class="keywords">	
	布偶貓買賣,布偶幼貓買賣,台中布偶貓買賣,梧棲布偶貓買賣,北屯布偶貓買賣,台中布偶幼貓買賣<span id="show_itemb1" style="display:none">,梧棲布偶幼貓買賣,北屯布偶幼貓買賣,布偶貓舍,台中布偶貓舍,梧棲布偶貓舍,北屯布偶貓舍,布偶貓專賣店,台中布偶貓專賣店,梧棲布偶貓專賣店,北屯布偶貓專賣店,布偶貓繁殖場,台中布偶貓繁殖場,梧棲布偶貓繁殖場,北屯布偶貓繁殖場,飼養布偶貓,台中飼養布偶貓,梧棲飼養布偶貓,北屯飼養布偶貓,布偶貓領養,台中布偶貓領養,梧棲布偶貓領養,北屯布偶貓領養,純種長毛貓,台中純種長毛貓,梧棲純種長毛貓,北屯純種長毛貓,布偶幼貓,台中布偶幼貓,梧棲布偶幼貓,北屯布偶幼貓,買布偶幼貓,台中買布偶幼貓,梧棲買布偶幼貓,北屯買布偶幼貓,貓舍,台中貓舍,梧棲貓舍,北屯貓舍,貓咪買賣,台中貓咪買賣,梧棲貓咪買賣,北屯貓咪買賣,貓咪專賣店,台中貓咪專賣店,梧棲貓咪專賣店,北屯貓咪專賣店,合法貓舍,台中合法貓舍,梧棲合法貓舍,北屯合法貓舍,合法買貓,台中合法買貓,梧棲合法買貓,北屯合法買貓,幼貓買賣,台中幼貓買賣,梧棲幼貓買賣,北屯幼貓買賣,幼貓買賣推薦,台中幼貓買賣推薦,幼貓出售,台中幼貓出售,梧棲幼貓出售,北屯幼貓出售</span>&nbsp;&nbsp;<span id="NoButtonb1"><input type="button" value="更多" style="width:50px;height:20px;" onclick="MoreItem('yes','b1')"/></span><span id="YesButtonb1" style="display:none"><input type="button" value="隱藏" style="width:50px;height:20px;" onclick="MoreItem('no','b1')"/></span></p>
</footer>
			
</div><!-- #page -->

<script src='js/main.js'></script>
<script type="text/javascript" src="js/menu_v2_2020.js"></script>

	</body>
</html>